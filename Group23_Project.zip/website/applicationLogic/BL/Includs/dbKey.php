<?php
ob_start();
/*------CONSTANTS----------*/
define("dbHost", "sql111.byethost31.com");
define("dbUser", "b31_19455527");
define("dbPass", "ymewebdev");
define("dbName", "b31_19455527_CarAgency"); 
?>