function initPhoneCall() {
    var numToCall = '+11111111';
    window.location.href = 'tel://' + numToCall;
}
